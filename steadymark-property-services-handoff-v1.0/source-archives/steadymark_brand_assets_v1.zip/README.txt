SteadyMark Property Services — Brand Asset Pack

Source:
Approved SteadyMark Identity Refinement v1.1 raster reference.

Included:
- Primary color wordmark, transparent PNG
- Stacked color wordmark, transparent PNG
- Graphite monochrome wordmark, transparent PNG
- White monochrome wordmark, transparent PNG
- Clay registration mark, transparent PNG
- Favicon/app-mark PNGs: 16, 32, 48, 180, 512 px
- Palette reference image
- Palette JSON and CSS tokens
- Approved identity-board reference

Canonical palette:
Working Surface  #F4EFEA
Graphite         #2E2E2E
Clay / Oxide     #B2553C
Stone            #C9C2B8
Steel            #8A9399

Important:
These logo files are clean raster extractions from the approved identity-board image.
They preserve the approved visual reference, but they are not a mathematically reconstructed
vector master. A true SVG/vector master should be reconstructed separately before print,
vehicle graphics, embroidery, or other large-format physical production.
